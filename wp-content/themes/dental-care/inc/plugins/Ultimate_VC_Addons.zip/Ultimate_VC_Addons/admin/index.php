<?php
/*Silence is Golden*/